package dbmanagment;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("shopping")
public class ShopAction{

	@Autowired
	UserBean userbean;
	
	public UserBean getUserbean() {
		return userbean;
	}
     Session session=SessionUtility.GetSessionConnection();
	public void setUserbean(UserBean userbean) {
		this.userbean = userbean;
	}
	
	@Autowired
	ProductBean pbean;

	public ProductBean getPbean() {
		return pbean;
	}

	public void setPbean(ProductBean pbean) {
		this.pbean = pbean;
	}

	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView moveShoppingPage()
	{
		
		String hql = "FROM Product";
		
		Query query = session.createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Product> results = query.list();
	
	ModelAndView mdl=new ModelAndView();
	ProductBean pbean=new ProductBean();
	mdl.setViewName("shop1");
	mdl.addObject("pbean",pbean);
	mdl.addObject("products",results);
	
		
		return mdl;
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView shoppingproduct(ProductBean pbean,HttpSession session)
	{
		ModelAndView mdl=new ModelAndView();
		for (String s : pbean.getProduct()) {	
			if(s!=null)session.setAttribute(s,s);	
		}
			mdl.addObject("pbean",pbean);
			mdl.setViewName(pbean.getPage());	
			return mdl;
		
	}
	
	
}
